#script for lab2
color = raw_input("What's your favorite color? ")
animal = raw_input("What's your favorite animal? ")
number = raw_input("What's your favorite number? ")
print "Ok, I guess your ideal pet would be a",color,animal,"with",number,"legs!"
